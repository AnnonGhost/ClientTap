import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import TrustStrip from './sections/TrustStrip';
import Problem from './sections/Problem';
import Solution from './sections/Solution';
import Services from './sections/Services';
import DemoShowcase from './sections/DemoShowcase';
import WhatsAppFunnel from './sections/WhatsAppFunnel';
import Industries from './sections/Industries';
import Results from './sections/Results';
import Testimonials from './sections/Testimonials';
import Pricing from './sections/Pricing';
import Process from './sections/Process';
import FinalCTA from './sections/FinalCTA';
import Footer from './sections/Footer';
import FloatingWhatsApp from './sections/FloatingWhatsApp';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize scroll-triggered animations for flowing sections
    const ctx = gsap.context(() => {
      // Animate sections on scroll
      gsap.utils.toArray<HTMLElement>('.animate-section').forEach((section) => {
        gsap.fromTo(section,
          { opacity: 0.9, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            }
          }
        );
      });

      // Stagger animate cards
      gsap.utils.toArray<HTMLElement>('.stagger-card').forEach((card, i) => {
        gsap.fromTo(card,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            }
          }
        );
      });
    }, mainRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={mainRef} className="relative min-h-screen bg-dark overflow-x-hidden">
      {/* Noise overlay */}
      <div className="noise-overlay" />
      
      {/* Gradient mesh background */}
      <div className="fixed inset-0 gradient-mesh pointer-events-none" />
      
      {/* Grid pattern */}
      <div className="fixed inset-0 grid-pattern pointer-events-none" />
      
      {/* Navigation */}
      <Navbar />
      
      {/* Main content */}
      <main className="relative z-10">
        <Hero />
        <TrustStrip />
        <Problem />
        <Solution />
        <Services />
        <DemoShowcase />
        <WhatsAppFunnel />
        <Industries />
        <Results />
        <Testimonials />
        <Pricing />
        <Process />
        <FinalCTA />
        <Footer />
      </main>
      
      {/* Floating WhatsApp button */}
      <FloatingWhatsApp />
    </div>
  );
}

export default App;
