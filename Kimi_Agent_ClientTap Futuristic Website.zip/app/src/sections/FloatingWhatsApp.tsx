import { useState, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';

const FloatingWhatsApp = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isTooltipOpen, setIsTooltipOpen] = useState(false);

  useEffect(() => {
    // Show button after scrolling down a bit
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-open tooltip after 5 seconds when visible
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setIsTooltipOpen(true);
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  // Close tooltip when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.whatsapp-widget')) {
        setIsTooltipOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <div
      className={`whatsapp-widget fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'
      }`}
    >
      {/* Tooltip */}
      <div
        className={`relative bg-white rounded-2xl p-4 shadow-xl max-w-xs transition-all duration-300 ${
          isTooltipOpen
            ? 'opacity-100 translate-y-0'
            : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <button
          onClick={() => setIsTooltipOpen(false)}
          className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center text-gray-400 hover:text-gray-600"
        >
          <X className="w-4 h-4" />
        </button>
        <p className="text-sm text-gray-700 pr-4">
          👋 Need a website? Chat with us on WhatsApp for a free consultation!
        </p>
        <div className="absolute bottom-0 right-6 w-3 h-3 bg-white transform rotate-45 translate-y-1/2" />
      </div>

      {/* WhatsApp Button */}
      <a
        href="https://wa.me/918930637833"
        target="_blank"
        rel="noopener noreferrer"
        className="group relative flex items-center justify-center w-16 h-16 bg-whatsapp rounded-full shadow-lg hover:shadow-whatsapp/30 hover:scale-110 transition-all duration-300"
        onClick={() => setIsTooltipOpen(false)}
      >
        {/* Pulse animation */}
        <span className="absolute inset-0 rounded-full bg-whatsapp animate-ping opacity-20" />
        
        {/* Icon */}
        <MessageCircle className="w-8 h-8 text-white fill-white" />
        
        {/* Hover label */}
        <span className="absolute right-full mr-4 px-4 py-2 bg-dark-light text-white text-sm font-medium rounded-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none border border-white/10">
          Chat on WhatsApp
        </span>
      </a>
    </div>
  );
};

export default FloatingWhatsApp;
