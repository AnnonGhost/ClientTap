import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, MessageCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const DemoShowcase = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const demosRef = useRef<HTMLDivElement>(null);

  const demos = [
    {
      title: 'Bakery Website',
      category: 'Food & Beverage',
      image: '/images/demo_bakery.jpg',
      features: ['Online ordering', 'Menu showcase', 'WhatsApp integration'],
    },
    {
      title: 'Salon Website',
      category: 'Beauty & Wellness',
      image: '/images/demo_salon.jpg',
      features: ['Booking system', 'Service menu', 'Staff profiles'],
    },
    {
      title: 'Gym Website',
      category: 'Fitness',
      image: '/images/demo_gym.jpg',
      features: ['Membership plans', 'Class schedules', 'Trainer profiles'],
    },
    {
      title: 'Real Estate Website',
      category: 'Property',
      image: '/images/demo_realestate.jpg',
      features: ['Property listings', 'Virtual tours', 'Lead capture'],
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate demo cards
      const cards = demosRef.current?.querySelectorAll('.demo-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 50, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: demosRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="demos"
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            Live Demos
          </span>
          <h2 className="section-heading mb-6">
            See What We Can{' '}
            <span className="gradient-text">Build For You</span>
          </h2>
          <p className="section-subheading">
            Browse our portfolio of high-converting websites built for local businesses 
            across different industries.
          </p>
        </div>

        {/* Demos Grid */}
        <div
          ref={demosRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {demos.map((demo, index) => (
            <div
              key={index}
              className="demo-card group relative overflow-hidden rounded-3xl bg-dark-light border border-white/5 hover:border-violet/30 transition-all duration-500"
            >
              {/* Image */}
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={demo.image}
                  alt={demo.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/50 to-transparent" />
                
                {/* Category badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 text-xs font-medium text-white bg-white/10 backdrop-blur-sm rounded-full">
                    {demo.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-heading font-semibold text-white mb-3">
                  {demo.title}
                </h3>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {demo.features.map((feature, fIndex) => (
                    <span
                      key={fIndex}
                      className="text-xs text-muted-foreground"
                    >
                      {feature}{fIndex < demo.features.length - 1 && ' •'}
                    </span>
                  ))}
                </div>

                {/* Buttons */}
                <div className="flex gap-3">
                  <button className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-violet/10 hover:bg-violet/20 text-violet text-sm font-medium rounded-xl transition-colors duration-300">
                    <ExternalLink className="w-4 h-4" />
                    <span>View Demo</span>
                  </button>
                  <a
                    href="https://wa.me/918930637833"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-whatsapp/10 hover:bg-whatsapp/20 text-whatsapp text-sm font-medium rounded-xl transition-colors duration-300"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Get Similar</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All CTA */}
        <div className="mt-12 text-center">
          <a
            href="https://wa.me/918930637833"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary inline-flex items-center gap-2"
          >
            <span>Request Custom Demo</span>
            <MessageCircle className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default DemoShowcase;
