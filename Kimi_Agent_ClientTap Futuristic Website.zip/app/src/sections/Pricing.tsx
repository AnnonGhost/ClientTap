import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Sparkles, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Pricing = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const pricingRef = useRef<HTMLDivElement>(null);

  const plans = [
    {
      name: 'Starter',
      description: 'Perfect for small businesses just getting started',
      price: '7,500',
      priceNote: 'Starting price',
      features: [
        '5-page professional website',
        'WhatsApp click-to-chat',
        'Mobile-responsive design',
        'Basic SEO setup',
        'Contact form integration',
        '1 month support',
      ],
      cta: 'Get Started',
      popular: false,
    },
    {
      name: 'Growth',
      description: 'For businesses ready to scale their online presence',
      price: '12,000',
      priceNote: 'Most popular',
      features: [
        'Everything in Starter',
        '10-page website',
        'WhatsApp automation',
        'Lead capture forms',
        'Google Business setup',
        'Local SEO optimization',
        'Social media integration',
        '3 months support',
      ],
      cta: 'Get Started',
      popular: true,
    },
    {
      name: 'Pro',
      description: 'Complete solution for established businesses',
      price: '20,000',
      priceNote: 'Full package',
      features: [
        'Everything in Growth',
        'Unlimited pages',
        'Custom functionality',
        'Advanced automation',
        'E-commerce integration',
        'Priority support',
        'Monthly analytics report',
        '6 months support',
      ],
      cta: 'Contact Us',
      popular: false,
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate pricing cards
      const cards = pricingRef.current?.querySelectorAll('.pricing-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: pricingRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="relative py-24 lg:py-32 w-full"
    >
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-violet/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="w-full px-6 lg:px-12 relative">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            Simple Pricing
          </span>
          <h2 className="section-heading mb-6">
            Invest in Your{' '}
            <span className="gradient-text">Business Growth</span>
          </h2>
          <p className="section-subheading">
            Transparent pricing with no hidden fees. Choose the plan that fits 
            your business needs.
          </p>
        </div>

        {/* Pricing Cards */}
        <div
          ref={pricingRef}
          className="grid md:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto"
        >
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`pricing-card relative p-8 rounded-3xl ${
                plan.popular
                  ? 'glass-card-strong border-violet/30 scale-105 z-10'
                  : 'glass-card hover:border-violet/20'
              } transition-all duration-500`}
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="flex items-center gap-2 px-4 py-2 bg-violet rounded-full">
                    <Sparkles className="w-4 h-4 text-white" />
                    <span className="text-sm font-medium text-white">Most Popular</span>
                  </div>
                </div>
              )}

              {/* Plan header */}
              <div className="text-center mb-8">
                <h3 className="text-xl font-heading font-semibold text-white mb-2">
                  {plan.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  {plan.description}
                </p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-lg text-muted-foreground">₹</span>
                  <span className="text-5xl font-heading font-bold text-white">
                    {plan.price}
                  </span>
                </div>
                <span className="text-sm text-muted-foreground">{plan.priceNote}</span>
              </div>

              {/* Features */}
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-violet/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check className="w-3 h-3 text-violet" />
                    </div>
                    <span className="text-sm text-white/80">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <a
                href="https://wa.me/918930637833"
                target="_blank"
                rel="noopener noreferrer"
                className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all duration-300 ${
                  plan.popular
                    ? 'bg-violet text-white hover:bg-violet-dark hover:shadow-glow'
                    : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
                }`}
              >
                <span>{plan.cta}</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>

        {/* Custom quote note */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            Need something custom?{' '}
            <a
              href="https://wa.me/918930637833"
              target="_blank"
              rel="noopener noreferrer"
              className="text-violet hover:underline"
            >
              Let&apos;s discuss your requirements
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
