import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Users, 
  MousePointer, 
  MessageCircle, 
  CheckCircle,
  ArrowRight,
  Zap
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const WhatsAppFunnel = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const flowRef = useRef<HTMLDivElement>(null);
  const arrowsRef = useRef<HTMLDivElement>(null);

  const flowSteps = [
    {
      icon: Users,
      title: 'Visitor',
      description: 'Potential customer visits your website',
      color: 'bg-blue-500/20 text-blue-400',
    },
    {
      icon: MousePointer,
      title: 'Click WhatsApp',
      description: 'One-click to start a conversation',
      color: 'bg-violet/20 text-violet',
    },
    {
      icon: MessageCircle,
      title: 'Chat',
      description: 'Instant reply with auto-responses',
      color: 'bg-green-500/20 text-green-400',
    },
    {
      icon: CheckCircle,
      title: 'Conversion',
      description: 'Lead captured, sale made',
      color: 'bg-amber-500/20 text-amber-400',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate flow steps
      const steps = flowRef.current?.querySelectorAll('.flow-step');
      if (steps) {
        gsap.fromTo(
          steps,
          { opacity: 0, y: 40, scale: 0.9 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.2,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: flowRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Animate arrows
      const arrows = arrowsRef.current?.querySelectorAll('.flow-arrow');
      if (arrows) {
        gsap.fromTo(
          arrows,
          { opacity: 0, x: -20 },
          {
            opacity: 1,
            x: 0,
            duration: 0.4,
            stagger: 0.2,
            delay: 0.3,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: flowRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        // Continuous pulse animation for arrows
        arrows.forEach((arrow, i) => {
          gsap.to(arrow, {
            x: 5,
            duration: 0.8,
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut',
            delay: i * 0.2,
          });
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full overflow-hidden"
    >
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-violet/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="w-full px-6 lg:px-12 relative">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-whatsapp/10 border border-whatsapp/20 text-whatsapp text-sm font-medium mb-6">
            WhatsApp Integration
          </span>
          <h2 className="section-heading mb-6">
            Turn Visitors Into{' '}
            <span className="text-whatsapp">Customers Instantly</span>
          </h2>
          <p className="section-subheading">
            Our WhatsApp funnel captures leads the moment they show interest—
            no forms, no waiting, just instant conversations.
          </p>
        </div>

        {/* Flow Diagram */}
        <div ref={flowRef} className="relative">
          <div className="flex flex-col lg:flex-row items-center justify-center gap-4 lg:gap-6">
            {flowSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="flex items-center gap-4 lg:gap-6">
                  {/* Step Card */}
                  <div className="flow-step relative w-64 p-6 rounded-3xl glass-card-strong text-center group hover:border-whatsapp/30 transition-all duration-500">
                    {/* Icon */}
                    <div className={`w-16 h-16 mx-auto rounded-2xl ${step.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-8 h-8" />
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-heading font-semibold text-white mb-2">
                      {step.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {step.description}
                    </p>

                    {/* Step number */}
                    <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-violet flex items-center justify-center">
                      <span className="text-sm font-bold text-white">{index + 1}</span>
                    </div>
                  </div>

                  {/* Arrow (except for last item) */}
                  {index < flowSteps.length - 1 && (
                    <div ref={index === 0 ? arrowsRef : undefined} className="flow-arrow hidden lg:flex items-center justify-center">
                      <ArrowRight className="w-8 h-8 text-violet/50" />
                    </div>
                  )}

                  {/* Mobile arrow */}
                  {index < flowSteps.length - 1 && (
                    <div className="lg:hidden flex items-center justify-center py-2">
                      <ArrowRight className="w-6 h-6 text-violet/50 rotate-90" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <div className="text-center p-6 rounded-2xl bg-dark-light/50 border border-white/5">
            <div className="text-3xl font-heading font-bold text-whatsapp mb-2">85%</div>
            <div className="text-sm text-muted-foreground">Open Rate on WhatsApp</div>
          </div>
          <div className="text-center p-6 rounded-2xl bg-dark-light/50 border border-white/5">
            <div className="text-3xl font-heading font-bold text-violet mb-2">3x</div>
            <div className="text-sm text-muted-foreground">Faster Response Time</div>
          </div>
          <div className="text-center p-6 rounded-2xl bg-dark-light/50 border border-white/5">
            <div className="text-3xl font-heading font-bold text-amber-400 mb-2">24/7</div>
            <div className="text-sm text-muted-foreground">Auto-Reply Available</div>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <a
            href="https://wa.me/918930637833"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary inline-flex items-center gap-2 bg-whatsapp hover:bg-whatsapp-dark"
          >
            <Zap className="w-5 h-5" />
            <span>Start Getting Leads Now</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default WhatsAppFunnel;
