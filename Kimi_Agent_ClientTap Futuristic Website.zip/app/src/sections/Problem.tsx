import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  MonitorX, 
  Users, 
  Clock, 
  TrendingDown 
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Problem = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const problems = [
    {
      icon: MonitorX,
      title: 'No Proper Website',
      description: 'Your business is virtually invisible to potential customers searching online.',
    },
    {
      icon: Users,
      title: 'No Lead System',
      description: 'Visitors come and go without leaving their contact information.',
    },
    {
      icon: Clock,
      title: 'No Automation',
      description: 'You spend hours on repetitive tasks that could be automated.',
    },
    {
      icon: TrendingDown,
      title: 'Losing Customers Daily',
      description: 'Competitors with better online presence capture your potential clients.',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate cards with stagger
      const cards = cardsRef.current?.querySelectorAll('.problem-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 50, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-sm font-medium mb-6">
            The Problem
          </span>
          <h2 className="section-heading mb-6">
            Most Local Businesses Are{' '}
            <span className="text-red-400">Invisible Online</span>
          </h2>
          <p className="section-subheading">
            Without a proper digital presence, you&apos;re missing out on customers 
            who are actively searching for services like yours right now.
          </p>
        </div>

        {/* Problem Cards */}
        <div
          ref={cardsRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {problems.map((problem, index) => {
            const Icon = problem.icon;
            return (
              <div
                key={index}
                className="problem-card group relative p-6 lg:p-8 rounded-3xl bg-dark-light/50 border border-white/5 hover:border-red-500/30 transition-all duration-500 hover:-translate-y-2"
              >
                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mb-6 group-hover:bg-red-500/20 transition-colors duration-300">
                  <Icon className="w-7 h-7 text-red-400" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-heading font-semibold text-white mb-3">
                  {problem.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {problem.description}
                </p>

                {/* Hover glow */}
                <div className="absolute inset-0 rounded-3xl bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
              </div>
            );
          })}
        </div>

        {/* Bottom stat */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 px-8 py-4 rounded-2xl bg-dark-light/80 border border-white/5">
            <div className="text-4xl font-heading font-bold text-red-400">70%</div>
            <div className="text-left">
              <div className="text-white font-medium">of local searches</div>
              <div className="text-sm text-muted-foreground">result in a purchase within 24 hours</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problem;
