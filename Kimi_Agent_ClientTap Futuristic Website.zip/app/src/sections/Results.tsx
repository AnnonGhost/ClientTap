import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  TrendingUp, 
  CalendarCheck, 
  Award, 
  DollarSign 
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Results = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const countersRef = useRef<HTMLDivElement>(null);
  const [countersStarted, setCountersStarted] = useState(false);

  const results = [
    {
      icon: TrendingUp,
      value: 150,
      suffix: '%',
      label: 'More Daily Inquiries',
      description: 'Average increase in leads within 30 days',
    },
    {
      icon: CalendarCheck,
      value: 80,
      suffix: '%',
      label: 'More Bookings',
      description: 'Improvement in appointment conversions',
    },
    {
      icon: Award,
      value: 95,
      suffix: '%',
      label: 'Better Brand Image',
      description: 'Customer perception improvement',
    },
    {
      icon: DollarSign,
      value: 40,
      suffix: '%',
      label: 'Higher-Paying Customers',
      description: 'Increase in average order value',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Trigger counters when section is visible
      ScrollTrigger.create({
        trigger: countersRef.current,
        start: 'top 80%',
        onEnter: () => setCountersStarted(true),
      });

      // Animate result cards
      const cards = countersRef.current?.querySelectorAll('.result-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: countersRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full"
    >
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-violet/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="w-full px-6 lg:px-12 relative">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium mb-6">
            Proven Results
          </span>
          <h2 className="section-heading mb-6">
            What You Can{' '}
            <span className="text-green-400">Expect</span>
          </h2>
          <p className="section-subheading">
            Our clients see measurable improvements in their business metrics 
            within the first month of going live.
          </p>
        </div>

        {/* Results Grid */}
        <div
          ref={countersRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {results.map((result, index) => {
            const Icon = result.icon;
            return (
              <div
                key={index}
                className="result-card group relative p-8 rounded-3xl glass-card-strong text-center hover:border-green-500/30 transition-all duration-500"
              >
                {/* Icon */}
                <div className="w-14 h-14 mx-auto rounded-2xl bg-green-500/10 flex items-center justify-center mb-6 group-hover:bg-green-500/20 group-hover:scale-110 transition-all duration-300">
                  <Icon className="w-7 h-7 text-green-400" />
                </div>

                {/* Counter */}
                <div className="mb-3">
                  <Counter 
                    value={result.value} 
                    suffix={result.suffix}
                    started={countersStarted}
                  />
                </div>

                {/* Label */}
                <h3 className="text-lg font-heading font-semibold text-white mb-2">
                  {result.label}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {result.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Bottom note */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-dark-light/80 border border-white/5">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
            <span className="text-sm text-muted-foreground">
              Results based on average client performance over 30 days
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

// Counter component
interface CounterProps {
  value: number;
  suffix: string;
  started: boolean;
}

const Counter = ({ value, suffix, started }: CounterProps) => {
  const [count, setCount] = useState(0);
  const countRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!started) return;

    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [started, value]);

  return (
    <span 
      ref={countRef}
      className="text-5xl lg:text-6xl font-heading font-bold text-white"
    >
      {count}{suffix}
    </span>
  );
};

export default Results;
