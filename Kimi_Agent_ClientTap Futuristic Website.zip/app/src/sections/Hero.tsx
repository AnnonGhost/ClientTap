import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowRight, Play, Sparkles } from 'lucide-react';

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Create entrance animation timeline
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Animate image card
      tl.fromTo(
        imageRef.current,
        { x: '-12vw', opacity: 0 },
        { x: 0, opacity: 1, duration: 0.9 },
        0
      );

      // Animate headline with word stagger
      tl.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7 },
        0.2
      );

      // Animate subheadline
      tl.fromTo(
        subheadlineRef.current,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        0.4
      );

      // Animate CTAs
      tl.fromTo(
        ctaRef.current,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        0.5
      );

      // Animate small card
      tl.fromTo(
        cardRef.current,
        { x: '10vw', opacity: 0, scale: 0.96 },
        { x: 0, opacity: 1, scale: 1, duration: 0.8, ease: 'back.out(1.4)' },
        0.6
      );

      // Animate particles
      const particles = particlesRef.current?.querySelectorAll('.particle');
      if (particles) {
        particles.forEach((particle, i) => {
          gsap.to(particle, {
            y: 'random(-100, 100)',
            x: 'random(-50, 50)',
            duration: 'random(3, 6)',
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut',
            delay: i * 0.2,
          });
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen w-full flex items-center pt-20 overflow-hidden"
    >
      {/* Animated particles */}
      <div ref={particlesRef} className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="particle absolute w-1 h-1 bg-violet/40 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      {/* Glow effect behind card */}
      <div className="absolute right-[10%] bottom-[15%] w-80 h-80 bg-violet/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="w-full px-6 lg:px-12 py-12 lg:py-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left: Image Card */}
          <div
            ref={imageRef}
            className="relative order-2 lg:order-1"
          >
            <div className="relative rounded-3xl overflow-hidden aspect-[4/3] shadow-card">
              <img
                src="/images/hero_office.jpg"
                alt="Modern business collaboration"
                className="w-full h-full object-cover"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-dark/60 via-transparent to-transparent" />
              
              {/* Floating badge */}
              <div className="absolute bottom-6 left-6 flex items-center gap-2 px-4 py-2 glass-card-strong rounded-full">
                <Sparkles className="w-4 h-4 text-violet" />
                <span className="text-sm font-medium text-white">AI-Powered</span>
              </div>
            </div>

            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border border-violet/20 rounded-2xl -z-10" />
            <div className="absolute -bottom-4 -right-4 w-32 h-32 border border-violet/10 rounded-3xl -z-10" />
          </div>

          {/* Right: Content */}
          <div className="order-1 lg:order-2 lg:pl-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet/10 border border-violet/20 mb-6">
              <span className="w-2 h-2 bg-violet rounded-full animate-pulse" />
              <span className="text-sm font-medium text-violet-light">
                Growth Systems for Local Businesses
              </span>
            </div>

            {/* Headline */}
            <h1
              ref={headlineRef}
              className="font-heading font-bold text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white leading-[1.1] mb-6"
            >
              Websites That Turn{' '}
              <span className="gradient-text">Visitors Into Customers</span>
            </h1>

            {/* Subheadline */}
            <p
              ref={subheadlineRef}
              className="text-lg lg:text-xl text-muted-foreground leading-relaxed mb-8 max-w-xl"
            >
              AI-optimized layouts, instant lead capture, and a checkout experience 
              built for salons, gyms, clinics, and local businesses in India.
            </p>

            {/* CTAs */}
            <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4">
              <a
                href="https://wa.me/918930637833"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary flex items-center justify-center gap-2 group"
              >
                <span>Get Clients on WhatsApp</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <button
                onClick={() => document.getElementById('demos')?.scrollIntoView({ behavior: 'smooth' })}
                className="btn-secondary flex items-center justify-center gap-2 group"
              >
                <Play className="w-5 h-5" />
                <span>View Live Demos</span>
              </button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 mt-10 pt-10 border-t border-white/5">
              <div>
                <div className="text-3xl font-heading font-bold text-white">500+</div>
                <div className="text-sm text-muted-foreground">Websites Built</div>
              </div>
              <div>
                <div className="text-3xl font-heading font-bold text-white">3x</div>
                <div className="text-sm text-muted-foreground">Avg. Conversion Boost</div>
              </div>
              <div>
                <div className="text-3xl font-heading font-bold text-white">48h</div>
                <div className="text-sm text-muted-foreground">Go Live Time</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Small UI Card - Bottom Right */}
      <div
        ref={cardRef}
        className="hidden lg:block absolute right-6 lg:right-12 bottom-24 w-72 glass-card-strong p-5"
      >
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-violet/20 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-violet" />
          </div>
          <div>
            <div className="text-sm font-semibold text-white">Conversion-Optimized</div>
            <div className="text-xs text-muted-foreground">Built for results</div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Built for salons, gyms, clinics, real estate, and more.
        </p>
      </div>
    </section>
  );
};

export default Hero;
