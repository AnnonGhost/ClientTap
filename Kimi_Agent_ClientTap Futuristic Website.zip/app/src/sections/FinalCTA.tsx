import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MessageCircle, Clock, Zap, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const FinalCTA = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0, y: 50, scale: 0.95 },
        {
          opacity: 1,
          y: 0,
          scale: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: contentRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative py-24 lg:py-32 w-full overflow-hidden"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet/5 to-transparent pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-violet/20 rounded-full blur-[150px] pointer-events-none" />

      <div className="w-full px-6 lg:px-12 relative">
        <div
          ref={contentRef}
          className="max-w-4xl mx-auto text-center"
        >
          {/* Main CTA Card */}
          <div className="glass-card-strong p-10 lg:p-16 rounded-[2.5rem] relative overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-violet/10 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-violet/10 rounded-full blur-[60px] translate-y-1/2 -translate-x-1/2" />

            {/* Content */}
            <div className="relative">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet/10 border border-violet/20 mb-8">
                <Zap className="w-4 h-4 text-violet" />
                <span className="text-sm font-medium text-violet">
                  Limited Time Offer
                </span>
              </div>

              {/* Headline */}
              <h2 className="font-heading font-bold text-4xl sm:text-5xl lg:text-6xl text-white leading-tight mb-6">
                Ready to Get{' '}
                <span className="gradient-text">More Customers?</span>
              </h2>

              {/* Subheadline */}
              <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
                Join 500+ local businesses already growing with ClientTap. 
                Your new website can be live in just 48 hours.
              </p>

              {/* Urgency badges */}
              <div className="flex flex-wrap justify-center gap-4 mb-10">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-dark-light/80 border border-white/5">
                  <Clock className="w-4 h-4 text-violet" />
                  <span className="text-sm text-white/80">48-hour delivery</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-dark-light/80 border border-white/5">
                  <MessageCircle className="w-4 h-4 text-whatsapp" />
                  <span className="text-sm text-white/80">WhatsApp integrated</span>
                </div>
              </div>

              {/* Primary CTA */}
              <a
                href="https://wa.me/918930637833"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex items-center gap-3 text-lg py-5 px-10 animate-pulse-glow"
              >
                <MessageCircle className="w-6 h-6" />
                <span>Chat on WhatsApp Now</span>
                <ArrowRight className="w-5 h-5" />
              </a>

              {/* Trust note */}
              <p className="mt-6 text-sm text-muted-foreground">
                No commitment required. Let&apos;s discuss your project first.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;
