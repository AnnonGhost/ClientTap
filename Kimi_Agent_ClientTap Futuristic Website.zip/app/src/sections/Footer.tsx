import { Zap, MessageCircle, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    services: [
      { label: 'Website Design', href: '#services' },
      { label: 'WhatsApp Automation', href: '#services' },
      { label: 'Lead Generation', href: '#services' },
      { label: 'Local SEO', href: '#services' },
    ],
    company: [
      { label: 'About Us', href: '#' },
      { label: 'Our Work', href: '#demos' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Contact', href: '#contact' },
    ],
    support: [
      { label: 'Help Center', href: '#' },
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' },
    ],
  };

  const scrollToSection = (href: string) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer className="relative w-full border-t border-white/5 bg-dark-light/30">
      <div className="w-full px-6 lg:px-12 py-16 lg:py-20">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Brand column */}
          <div className="lg:col-span-2">
            {/* Logo */}
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet to-violet-dark flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-heading font-bold text-white">
                ClientTap
              </span>
            </a>

            <p className="text-muted-foreground mb-6 max-w-sm">
              AI-powered growth systems for local businesses. 
              Websites, WhatsApp automation, and lead generation 
              that actually works.
            </p>

            {/* Contact info */}
            <div className="space-y-3">
              <a
                href="https://wa.me/918930637833"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-muted-foreground hover:text-whatsapp transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                <span>+91 89306 37833</span>
              </a>
              <a
                href="mailto:hello@clienttap.in"
                className="flex items-center gap-3 text-muted-foreground hover:text-violet transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>hello@clienttap.in</span>
              </a>
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="w-5 h-5" />
                <span>India & Global</span>
              </div>
            </div>
          </div>

          {/* Services column */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-6">
              Services
            </h4>
            <ul className="space-y-4">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-muted-foreground hover:text-violet transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company column */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-6">
              Company
            </h4>
            <ul className="space-y-4">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-muted-foreground hover:text-violet transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support column */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-6">
              Support
            </h4>
            <ul className="space-y-4">
              {footerLinks.support.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-muted-foreground hover:text-violet transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {currentYear} ClientTap. All rights reserved.
          </p>

          {/* WhatsApp CTA */}
          <a
            href="https://wa.me/918930637833"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-6 py-3 bg-whatsapp/10 hover:bg-whatsapp/20 text-whatsapp rounded-full transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="text-sm font-medium">Chat on WhatsApp</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
