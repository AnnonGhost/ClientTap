import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MessageSquare, Eye, Code, Rocket } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Process = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const stepsRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  const steps = [
    {
      icon: MessageSquare,
      number: '01',
      title: 'Contact',
      description: 'Reach out via WhatsApp and tell us about your business and goals.',
      duration: '5 minutes',
    },
    {
      icon: Eye,
      number: '02',
      title: 'Demo',
      description: 'We show you sample designs and finalize the perfect look for your brand.',
      duration: '30 minutes',
    },
    {
      icon: Code,
      number: '03',
      title: 'Build',
      description: 'Our team builds your website with all the features you need.',
      duration: '24-48 hours',
    },
    {
      icon: Rocket,
      number: '04',
      title: 'Go Live',
      description: 'Your website launches and starts bringing in leads immediately.',
      duration: 'Instant',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate timeline line
      if (lineRef.current) {
        gsap.fromTo(
          lineRef.current,
          { scaleY: 0 },
          {
            scaleY: 1,
            duration: 1.5,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: stepsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Animate steps
      const stepCards = stepsRef.current?.querySelectorAll('.step-card');
      if (stepCards) {
        gsap.fromTo(
          stepCards,
          { opacity: 0, x: -30 },
          {
            opacity: 1,
            x: 0,
            duration: 0.6,
            stagger: 0.2,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: stepsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            Our Process
          </span>
          <h2 className="section-heading mb-6">
            From Idea to{' '}
            <span className="gradient-text">Live in 48 Hours</span>
          </h2>
          <p className="section-subheading">
            Our streamlined process gets your business online quickly without 
            compromising on quality.
          </p>
        </div>

        {/* Timeline */}
        <div ref={stepsRef} className="relative max-w-4xl mx-auto">
          {/* Vertical line */}
          <div className="absolute left-8 lg:left-1/2 top-0 bottom-0 w-px bg-white/10 hidden sm:block">
            <div
              ref={lineRef}
              className="absolute inset-x-0 top-0 bg-gradient-to-b from-violet to-violet-dark origin-top"
              style={{ height: '100%' }}
            />
          </div>

          {/* Steps */}
          <div className="space-y-12 lg:space-y-16">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;

              return (
                <div
                  key={index}
                  className={`step-card relative flex flex-col sm:flex-row items-start sm:items-center gap-6 sm:gap-12 ${
                    isEven ? 'sm:flex-row' : 'sm:flex-row-reverse'
                  }`}
                >
                  {/* Content */}
                  <div className={`flex-1 ${isEven ? 'sm:text-right' : 'sm:text-left'}`}>
                    <div className={`glass-card-strong p-6 lg:p-8 rounded-3xl inline-block max-w-md ${
                      isEven ? 'sm:ml-auto' : 'sm:mr-auto'
                    }`}>
                      {/* Duration badge */}
                      <span className="inline-block px-3 py-1 text-xs font-medium text-violet bg-violet/10 rounded-full mb-4">
                        {step.duration}
                      </span>

                      <h3 className="text-xl font-heading font-semibold text-white mb-2">
                        {step.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {step.description}
                      </p>
                    </div>
                  </div>

                  {/* Center icon */}
                  <div className="relative flex-shrink-0">
                    <div className="w-16 h-16 rounded-2xl bg-violet flex items-center justify-center shadow-glow z-10 relative">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    {/* Step number */}
                    <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-dark border border-violet flex items-center justify-center">
                      <span className="text-xs font-bold text-violet">{step.number}</span>
                    </div>
                  </div>

                  {/* Empty space for alternating layout */}
                  <div className="flex-1 hidden sm:block" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <a
            href="https://wa.me/918930637833"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary inline-flex items-center gap-2"
          >
            <span>Start Your Project</span>
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Process;
