import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Monitor, 
  MessageCircle, 
  Funnel, 
  MapPin,
  ArrowRight
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Services = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);

  const services = [
    {
      icon: Monitor,
      title: 'Website Systems',
      description: 'High-converting business websites that load fast, look stunning, and turn visitors into leads.',
      features: ['Mobile-responsive', 'SEO-optimized', 'Fast loading', 'Custom design'],
      image: '/images/feature_workspace.jpg',
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Automation',
      description: 'Auto-replies, lead capture, and smart follow-ups that keep customers engaged 24/7.',
      features: ['Instant replies', 'Lead capture', 'Broadcast messages', 'Chatbot integration'],
      image: '/images/feature_chat.jpg',
    },
    {
      icon: Funnel,
      title: 'Lead Generation Funnels',
      description: 'Strategic funnels that bring qualified customers to your business every single day.',
      features: ['Landing pages', 'A/B testing', 'Conversion tracking', 'Retargeting'],
      image: '/images/feature_payments.jpg',
    },
    {
      icon: MapPin,
      title: 'Local SEO Setup',
      description: 'Rank higher on Google Maps and local search results to capture nearby customers.',
      features: ['Google Business', 'Local citations', 'Review management', 'Map optimization'],
      image: '/images/feature_analytics.jpg',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate service cards
      const cards = servicesRef.current?.querySelectorAll('.service-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: servicesRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            Our Services
          </span>
          <h2 className="section-heading mb-6">
            Everything You Need to{' '}
            <span className="gradient-text">Grow Online</span>
          </h2>
          <p className="section-subheading">
            From stunning websites to automated lead capture—we handle everything 
            so you can focus on running your business.
          </p>
        </div>

        {/* Services Grid */}
        <div
          ref={servicesRef}
          className="grid md:grid-cols-2 gap-6 lg:gap-8"
        >
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="service-card group relative overflow-hidden rounded-3xl glass-card hover:border-violet/30 transition-all duration-500"
              >
                {/* Background Image */}
                <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity duration-500">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/80 to-transparent" />
                </div>

                {/* Content */}
                <div className="relative p-8 lg:p-10">
                  {/* Icon */}
                  <div className="w-14 h-14 rounded-2xl bg-violet/20 flex items-center justify-center mb-6 group-hover:bg-violet/30 group-hover:scale-110 transition-all duration-300">
                    <Icon className="w-7 h-7 text-violet" />
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-2xl font-heading font-semibold text-white mb-3">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-8">
                    {service.features.map((feature, fIndex) => (
                      <span
                        key={fIndex}
                        className="px-3 py-1 text-xs font-medium text-violet-light bg-violet/10 rounded-full"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  {/* CTA */}
                  <a
                    href="https://wa.me/918930637833"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-violet font-medium group/link"
                  >
                    <span>Learn More</span>
                    <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                  </a>
                </div>

                {/* Hover glow */}
                <div className="absolute inset-0 rounded-3xl bg-violet/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;
