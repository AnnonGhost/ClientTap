import { 
  Globe, 
  Funnel, 
  Bot, 
  MapPin, 
  MessageCircle,
  TrendingUp,
  Zap,
  Shield
} from 'lucide-react';

const TrustStrip = () => {
  const items = [
    { icon: Globe, label: 'Websites' },
    { icon: Funnel, label: 'Funnels' },
    { icon: Bot, label: 'Automation' },
    { icon: MapPin, label: 'Local SEO' },
    { icon: MessageCircle, label: 'WhatsApp Systems' },
    { icon: TrendingUp, label: 'Analytics' },
    { icon: Zap, label: 'Fast Delivery' },
    { icon: Shield, label: 'Secure Hosting' },
  ];

  // Duplicate items for seamless loop
  const allItems = [...items, ...items];

  return (
    <section className="relative py-8 overflow-hidden border-y border-white/5 bg-dark-light/50">
      {/* Gradient fades on edges */}
      <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-dark to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-dark to-transparent z-10 pointer-events-none" />

      {/* Marquee container */}
      <div className="flex animate-marquee">
        {allItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="flex items-center gap-3 px-8 whitespace-nowrap"
            >
              <Icon className="w-5 h-5 text-violet" />
              <span className="text-sm font-medium text-white/80">{item.label}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-violet/40" />
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default TrustStrip;
