import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Scissors, 
  Dumbbell, 
  Cake, 
  Home,
  Stethoscope,
  Hotel,
  Truck,
  ArrowRight
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Industries = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const industriesRef = useRef<HTMLDivElement>(null);

  const industries = [
    { icon: Scissors, name: 'Salons', description: 'Beauty & hair styling' },
    { icon: Dumbbell, name: 'Gyms', description: 'Fitness & wellness' },
    { icon: Cake, name: 'Bakeries', description: 'Food & confectionery' },
    { icon: Home, name: 'Real Estate', description: 'Property & rentals' },
    { icon: Stethoscope, name: 'Clinics', description: 'Healthcare & dental' },
    { icon: Hotel, name: 'Hotels', description: 'Hospitality & stays' },
    { icon: Truck, name: 'Packers & Movers', description: 'Logistics & shifting' },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate industry cards
      const cards = industriesRef.current?.querySelectorAll('.industry-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 30, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.5,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: industriesRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            Industries We Serve
          </span>
          <h2 className="section-heading mb-6">
            Built For{' '}
            <span className="gradient-text">Your Business</span>
          </h2>
          <p className="section-subheading">
            We specialize in creating high-converting websites for local businesses 
            across these popular industries.
          </p>
        </div>

        {/* Industries Grid */}
        <div
          ref={industriesRef}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6"
        >
          {industries.map((industry, index) => {
            const Icon = industry.icon;
            return (
              <a
                key={index}
                href="https://wa.me/918930637833"
                target="_blank"
                rel="noopener noreferrer"
                className="industry-card group relative p-6 rounded-2xl bg-dark-light/50 border border-white/5 hover:border-violet/30 hover:bg-dark-light transition-all duration-300"
              >
                {/* Icon */}
                <div className="w-12 h-12 rounded-xl bg-violet/10 flex items-center justify-center mb-4 group-hover:bg-violet/20 group-hover:scale-110 transition-all duration-300">
                  <Icon className="w-6 h-6 text-violet" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-heading font-semibold text-white mb-1 group-hover:text-violet transition-colors duration-300">
                  {industry.name}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {industry.description}
                </p>

                {/* Arrow */}
                <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all duration-300">
                  <ArrowRight className="w-5 h-5 text-violet" />
                </div>
              </a>
            );
          })}
        </div>

        {/* More industries note */}
        <div className="mt-10 text-center">
          <p className="text-muted-foreground">
            Don&apos;t see your industry?{' '}
            <a
              href="https://wa.me/918930637833"
              target="_blank"
              rel="noopener noreferrer"
              className="text-violet hover:underline"
            >
              Let&apos;s talk
            </a>
            {' '}— we work with all local businesses.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Industries;
