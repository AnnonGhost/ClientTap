import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Layout, 
  MessageCircle, 
  Funnel, 
  Award 
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Solution = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const pillarsRef = useRef<HTMLDivElement>(null);

  const pillars = [
    {
      icon: Layout,
      title: 'Conversion Websites',
      description: 'High-converting, mobile-first websites designed to turn visitors into leads.',
      color: 'violet',
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Automation',
      description: 'Instant replies, lead capture, and automated follow-ups on WhatsApp.',
      color: 'green',
    },
    {
      icon: Funnel,
      title: 'Local Lead Funnels',
      description: 'Strategic funnels that attract and convert local customers consistently.',
      color: 'blue',
    },
    {
      icon: Award,
      title: 'Brand Positioning',
      description: 'Stand out from competitors with premium branding and positioning.',
      color: 'amber',
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate heading
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Animate pillars with stagger
      const pillars = pillarsRef.current?.querySelectorAll('.pillar-card');
      if (pillars) {
        gsap.fromTo(
          pillars,
          { opacity: 0, y: 50, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.12,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: pillarsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; border: string; text: string; glow: string }> = {
      violet: {
        bg: 'bg-violet/10',
        border: 'border-violet/30',
        text: 'text-violet',
        glow: 'group-hover:shadow-[0_0_30px_rgba(123,97,255,0.3)]',
      },
      green: {
        bg: 'bg-green-500/10',
        border: 'border-green-500/30',
        text: 'text-green-400',
        glow: 'group-hover:shadow-[0_0_30px_rgba(74,222,128,0.3)]',
      },
      blue: {
        bg: 'bg-blue-500/10',
        border: 'border-blue-500/30',
        text: 'text-blue-400',
        glow: 'group-hover:shadow-[0_0_30px_rgba(96,165,250,0.3)]',
      },
      amber: {
        bg: 'bg-amber-500/10',
        border: 'border-amber-500/30',
        text: 'text-amber-400',
        glow: 'group-hover:shadow-[0_0_30px_rgba(251,191,36,0.3)]',
      },
    };
    return colors[color] || colors.violet;
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 w-full"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Heading */}
        <div ref={headingRef} className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-violet/10 border border-violet/20 text-violet text-sm font-medium mb-6">
            The Solution
          </span>
          <h2 className="section-heading mb-6">
            ClientTap Builds{' '}
            <span className="gradient-text">Complete Growth Systems</span>
          </h2>
          <p className="section-subheading">
            We don&apos;t just build websites—we create end-to-end systems that 
            attract, engage, and convert your ideal customers.
          </p>
        </div>

        {/* Pillars Grid */}
        <div
          ref={pillarsRef}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            const colors = getColorClasses(pillar.color);
            return (
              <div
                key={index}
                className={`pillar-card group relative p-6 lg:p-8 rounded-3xl bg-dark-light/50 border border-white/5 hover:${colors.border} transition-all duration-500 hover:-translate-y-2 ${colors.glow}`}
              >
                {/* Icon */}
                <div className={`w-14 h-14 rounded-2xl ${colors.bg} flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110`}>
                  <Icon className={`w-7 h-7 ${colors.text}`} />
                </div>

                {/* Content */}
                <h3 className="text-xl font-heading font-semibold text-white mb-3">
                  {pillar.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {pillar.description}
                </p>

                {/* Number indicator */}
                <div className="absolute top-6 right-6 text-5xl font-heading font-bold text-white/5 group-hover:text-violet/10 transition-colors duration-300">
                  0{index + 1}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <a
            href="https://wa.me/918930637833"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary inline-flex items-center gap-2"
          >
            <span>Get Your Growth System</span>
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Solution;
